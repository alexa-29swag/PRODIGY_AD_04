package com.example.tictactoe;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private boolean enabled = true;
    private String winner = "";
    private char turn = 'X';
    private char[] chars = new char[9];
    private TextView label;
    private ArrayList<TextView> lbs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        label = findViewById(R.id.label);
        lbs = new ArrayList<>();

        lbs.add(findViewById(R.id.lb1));
        lbs.add(findViewById(R.id.lb2));
        lbs.add(findViewById(R.id.lb3));
        lbs.add(findViewById(R.id.lb4));
        lbs.add(findViewById(R.id.lb5));
        lbs.add(findViewById(R.id.lb6));
        lbs.add(findViewById(R.id.lb7));
        lbs.add(findViewById(R.id.lb8));
        lbs.add(findViewById(R.id.lb9));

        for (int i = 0; i < 9; i++) {
            int m = i;
            TextView lb = lbs.get(i);
            lb.setOnClickListener(view -> {
                if (enabled) {
                    if (lb.getText().toString().equals("")) {
                        lb.setText(String.valueOf(turn));
                        chars[m] = turn;

                        if (turn == 'X') {
                            lb.setTextColor(ContextCompat.getColor(this, R.color.blue));
                            turn = 'O';
                            label.setText("Player 2, it's your turn");
                        } else {
                            lb.setTextColor(ContextCompat.getColor(this, R.color.red));
                            turn = 'X';
                            label.setText("Player 1, it's your turn");
                        }
                    } else {
                        label.setText("Position Taken!");
                    }

                    if (checkWinner() && winner.equals("X")) {
                        label.setText("Player 1 Won!!!");
                        label.setTextColor(ContextCompat.getColor(this, R.color.blue));
                        enabled = false;
                    } else if (checkWinner() && winner.equals("O")) {
                        label.setText("Player 2 Won!!!");
                        label.setTextColor(ContextCompat.getColor(this, R.color.red));
                        enabled = false;
                    } else if (draw()) {
                        label.setText("Draw");
                        enabled = false;
                    }
                }
            });
        }
    }

    private boolean draw() {
        for (char a : chars) {
            if (a == 0) {
                return false;
            }
        }
        return true;
    }

    public void newGame(View view) {
        chars = new char[9];
        winner = "";
        label.setText("Player 1, it's your turn");
        label.setTextColor(ContextCompat.getColor(this, R.color.black));
        turn = 'X';
        enabled = true;

        for (TextView lb : lbs) {
            lb.setText("");
        }
    }

    private boolean checkWinner() {
        boolean win = false;

        if (chars[0] == chars[1] && chars[0] == chars[2] && chars[0] != 0) {
            win = true;
            winner = String.valueOf(chars[0]);
        } else if (chars[3] == chars[4] && chars[3] == chars[5] && chars[3] != 0) {
            win = true;
            winner = String.valueOf(chars[3]);
        } else if (chars[6] == chars[7] && chars[6] == chars[8] && chars[6] != 0) {
            win = true;
            winner = String.valueOf(chars[6]);
        } else if (chars[0] == chars[3] && chars[0] == chars[6] && chars[0] != 0) {
            win = true;
            winner = String.valueOf(chars[0]);
        } else if (chars[1] == chars[4] && chars[1] == chars[7] && chars[1] != 0) {
            win = true;
            winner = String.valueOf(chars[1]);
        } else if (chars[2] == chars[5] && chars[2] == chars[8] && chars[2] != 0) {
            win = true;
            winner = String.valueOf(chars[2]);
        } else if (chars[0] == chars[4] && chars[0] == chars[8] && chars[0] != 0) {
            win = true;
            winner = String.valueOf(chars[0]);
        } else if (chars[2] == chars[4] && chars[2] == chars[6] && chars[2] != 0) {
            win = true;
            winner = String.valueOf(chars[2]);
        }

        return win;
    }
}
